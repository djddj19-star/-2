package com.localnews.dangjinseosan

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class NewsItem(
    val title: String,
    val publisher: String,
    val link: String,
    val publishedAt: Long,
    val city: String,
    val category: String,
    val summary: String,
    val official: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NewsApp() }
    }
}

private val categories = listOf("전체", "사건사고·범죄", "화재·소방", "교통사고", "해양·선박", "경찰 공식", "소방 공식")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsApp() {
    val context = LocalContext.current
    var news by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var city by remember { mutableStateOf("전체") }
    var category by remember { mutableStateOf("전체") }
    var query by remember { mutableStateOf("") }
    var lastUpdated by remember { mutableStateOf<Long?>(null) }
    var expanded by remember { mutableStateOf(false) }

    fun refresh() {
        loading = true
        error = null
        (context as? MainActivity)?.lifecycleScope?.launch {
            try {
                val result = withContext(Dispatchers.IO) { NewsRepository.fetchLast72Hours() }
                news = result
                lastUpdated = System.currentTimeMillis()
                if (result.isEmpty()) error = "최근 72시간 내 검색된 기사가 없습니다. 새로고침하거나 검색어를 바꿔보세요."
            } catch (e: Exception) {
                error = "뉴스를 불러오지 못했습니다. 인터넷 연결을 확인한 뒤 다시 시도해 주세요."
            } finally { loading = false }
        } ?: run { loading = false; error = "앱 실행 환경을 확인해 주세요." }
    }

    LaunchedEffect(Unit) { refresh() }

    val filtered = remember(news, city, category, query) {
        news.filter {
            (city == "전체" || it.city == city) &&
            (category == "전체" || it.category == category) &&
            (query.isBlank() || it.title.contains(query, true) || it.publisher.contains(query, true) || it.summary.contains(query, true))
        }.sortedByDescending { it.publishedAt }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF174A7E), secondary = androidx.compose.ui.graphics.Color(0xFF3985B8))) {
        Scaffold(topBar = {
            TopAppBar(
                title = { Column { Text("당진·서산 뉴스모아", fontWeight = FontWeight.Bold); Text("최근 72시간 · 사건사고·공식 발표", style = MaterialTheme.typography.labelSmall) } },
                actions = { IconButton(onClick = { refresh() }, enabled = !loading) { Icon(Icons.Default.Refresh, contentDescription = "새로고침") } }
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("제목·언론사·요약 검색") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true, shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("전체", "당진", "서산").forEach { option -> FilterChip(selected = city == option, onClick = { city = option }, label = { Text(option) }) }
                }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = category, onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(),
                        label = { Text("뉴스 분류") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { category = option; expanded = false }) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${filtered.size}건", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(lastUpdated?.let { "갱신 ${formatDate(it)}" } ?: "실행 시 자동 검색", style = MaterialTheme.typography.labelSmall)
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp)) }
                if (!loading && filtered.isEmpty() && error == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("표시할 뉴스가 없습니다.") }
                } else {
                    LazyColumn(contentPadding = PaddingValues(top = 6.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(filtered, key = { it.link }) { item -> NewsCard(item) {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.link))) }
                        } }
                        item {
                            OfficialSourcesCard { url -> context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                        }
                    }
                }
                Text("요약은 RSS에 포함된 설명을 우선 사용하며, 설명이 없으면 제목 기반 요약으로 표시합니다. 원문과 저작권은 각 제공처에 있습니다.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}

@Composable
fun NewsCard(item: NewsItem, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(15.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SuggestionChip(onClick = {}, label = { Text(item.city) })
                Spacer(Modifier.width(5.dp))
                SuggestionChip(onClick = {}, label = { Text(item.category) })
                Spacer(Modifier.weight(1f))
                Text(formatDate(item.publishedAt), style = MaterialTheme.typography.labelSmall)
            }
            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Text(item.summary, style = MaterialTheme.typography.bodySmall, maxLines = 4, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.publisher, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (item.official) { Spacer(Modifier.width(6.dp)); Text("기관 관련", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.weight(1f))
                Text("원문 보기 ›", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
fun OfficialSourcesCard(open: (String) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(13.dp)) {
            Text("공식 발표 확인", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("기관 사이트에서 최신 공지·보도자료를 직접 확인할 수 있습니다.", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { open("https://www.cnpolice.go.kr/SEO/DJ/main.htm?Gubun=L03_02") }) { Text("당진경찰서 보도자료") }
            TextButton(onClick = { open("https://www.police.go.kr/user/bbs/BD_selectBbsList.do?q_bbsCode=1002") }) { Text("경찰청 보도자료") }
            TextButton(onClick = { open("https://www.dangjin.go.kr/cop/bbs/BBSMSTR_000000000014/selectBoardArticle.do?nttId=1134205") }) { Text("당진소방서 관련 당진시 공식 게시물 예시") }
            Text("서산경찰서·당진/서산소방서의 개별 보도자료 주소는 검증된 공식 주소를 확인한 뒤 연결해야 합니다.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

object NewsRepository {
    private const val BASE = "https://news.google.com/rss/search?q="
    private const val PARAMS = "&hl=ko&gl=KR&ceid=KR:ko"
    private data class FeedQuery(val query: String, val city: String, val forcedCategory: String? = null, val official: Boolean = false)

    fun fetchLast72Hours(): List<NewsItem> {
        val feeds = listOf(
            FeedQuery("당진 OR 당진시 when:3d", "당진"),
            FeedQuery("서산 OR 서산시 when:3d", "서산"),
            FeedQuery("당진 사건사고 범죄 when:3d", "당진"),
            FeedQuery("서산 사건사고 범죄 when:3d", "서산"),
            FeedQuery("당진 화재 소방 when:3d", "당진"),
            FeedQuery("서산 화재 소방 when:3d", "서산"),
            FeedQuery("당진 교통사고 when:3d", "당진"),
            FeedQuery("서산 교통사고 when:3d", "서산"),
            FeedQuery("당진 해양사고 선박 어선 when:3d", "당진"),
            FeedQuery("서산 해양사고 선박 어선 when:3d", "서산"),
            FeedQuery("당진경찰서 보도자료 when:3d", "당진", "경찰 공식", true),
            FeedQuery("서산경찰서 보도자료 when:3d", "서산", "경찰 공식", true),
            FeedQuery("당진소방서 보도자료 when:3d", "당진", "소방 공식", true),
            FeedQuery("서산소방서 보도자료 when:3d", "서산", "소방 공식", true),
            FeedQuery("site:cnpolice.go.kr 당진경찰서 when:3d", "당진", "경찰 공식", true),
            FeedQuery("site:cnpolice.go.kr 서산경찰서 when:3d", "서산", "경찰 공식", true),
        )
        val now = System.currentTimeMillis()
        val cutoff = now - 72L * 60L * 60L * 1000L
        val all = mutableListOf<NewsItem>()
        feeds.forEach { feed ->
            val url = BASE + URLEncoder.encode(feed.query, "UTF-8") + PARAMS
            all += parseFeed(url, feed).filter { it.publishedAt in cutoff..now }
        }
        return all.distinctBy { it.link.ifBlank { it.title } }.sortedByDescending { it.publishedAt }
    }

    private fun parseFeed(feedUrl: String, feed: FeedQuery): List<NewsItem> {
        val connection = (URL(feedUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 15000; requestMethod = "GET"
            setRequestProperty("User-Agent", "DangjinSeosanNews/2.0 Android")
        }
        try {
            connection.inputStream.use { input ->
                val parser = XmlPullParserFactory.newInstance().newPullParser()
                parser.setInput(input, "UTF-8")
                val result = mutableListOf<NewsItem>()
                var event = parser.eventType
                var inItem = false
                var title = ""; var link = ""; var pubDate = ""; var source = ""; var description = ""
                while (event != XmlPullParser.END_DOCUMENT) {
                    when (event) {
                        XmlPullParser.START_TAG -> when (parser.name) {
                            "item" -> { inItem = true; title = ""; link = ""; pubDate = ""; source = ""; description = "" }
                            "title" -> if (inItem) title = parser.nextText()
                            "link" -> if (inItem) link = parser.nextText()
                            "pubDate" -> if (inItem) pubDate = parser.nextText()
                            "source" -> if (inItem) source = parser.nextText()
                            "description" -> if (inItem) description = parser.nextText()
                        }
                        XmlPullParser.END_TAG -> if (parser.name == "item" && inItem) {
                            val time = parseRssDate(pubDate)
                            if (title.isNotBlank() && time > 0L) {
                                val cleanTitle = cleanHtml(title)
                                val cleanDescription = cleanHtml(description)
                                val category = feed.forcedCategory ?: classify(cleanTitle + " " + cleanDescription)
                                val summary = makeSummary(cleanDescription, cleanTitle)
                                result += NewsItem(cleanTitle, source.ifBlank { "Google 뉴스 검색" }, link, time, feed.city, category, summary, feed.official)
                            }
                            inItem = false
                        }
                    }
                    event = parser.next()
                }
                return result
            }
        } finally { connection.disconnect() }
    }

    private fun classify(text: String): String = when {
        listOf("해양사고", "선박", "어선", "낚시어선", "연안", "바다", "해상", "해경", "전복", "좌초").any { text.contains(it) } -> "해양·선박"
        listOf("화재", "소방", "불", "진압", "구조대", "소방서").any { text.contains(it) } -> "화재·소방"
        listOf("교통사고", "추돌", "충돌", "사망사고", "차량", "도로", "음주운전").any { text.contains(it) } -> "교통사고"
        listOf("경찰서", "검거", "범죄", "절도", "사기", "폭행", "마약", "보이스피싱", "수사").any { text.contains(it) } -> "사건사고·범죄"
        else -> "지역소식"
    }

    private fun makeSummary(description: String, title: String): String {
        if (description.isNotBlank()) return description.replace(Regex("\\s+"), " ").take(220).let { if (it.length == 220) "$it…" else it }
        return "제목 기반 요약: $title. 자세한 사실관계와 피해 규모는 원문 기사에서 확인하세요."
    }

    private fun cleanHtml(value: String): String = value
        .replace(Regex("<[^>]*>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
        .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("\\s+"), " ").trim()

    private fun parseRssDate(value: String): Long {
        for (pattern in listOf("EEE, dd MMM yyyy HH:mm:ss z", "EEE, dd MMM yyyy HH:mm z")) {
            try { val f = SimpleDateFormat(pattern, Locale.US); f.timeZone = TimeZone.getTimeZone("GMT"); return f.parse(value)?.time ?: continue }
            catch (_: Exception) { }
        }
        return -1L
    }
}

fun formatDate(timestamp: Long): String = SimpleDateFormat("MM.dd HH:mm", Locale.KOREA).format(Date(timestamp))
