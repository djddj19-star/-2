당진·서산 뉴스모아 GitHub 빌드용 파일

[업로드 방법 - 스마트폰]
1. GitHub 저장소(djddj19-star 계정의 기존 뉴스모아 저장소)를 엽니다.
2. Code 탭에서 Add file > Upload files를 선택합니다.
3. 이 압축파일 안의 파일과 폴더를 저장소 최상위(root)에 업로드합니다.
   - .github 폴더
   - dangjin_seosan_news_app 폴더
   - README_GITHUB_업로드.txt
4. Commit changes를 누릅니다.
5. Actions 탭에서 Build Dangjin Seosan APK를 선택합니다.
6. Run workflow > Run workflow를 누릅니다.
7. 성공하면 실행 결과 하단 Artifacts의 dangjin-seosan-news-apk를 눌러 APK를 받습니다.

중요:
- 기존 저장소의 다른 파일은 삭제하지 마세요.
- 폴더를 압축파일째 업로드하지 말고, 압축을 푼 내부 파일/폴더를 저장소 최상위에 올려야 합니다.
- 이 패키지는 ZIP 안의 Android 프로젝트를 저장소에 직접 두고 빌드하도록 구성했습니다.
- GitHub에 실제 업로드/커밋하거나 Actions 실행을 대신 수행한 것은 아닙니다.
